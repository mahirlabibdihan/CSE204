Queue.hpp: Abstract Queue class
AStack.hpp: Array based circular queue which will implement stack class
Link.hpp: Node for linked list
LStack.hpp: Link based queue which will implement stack class
main.cpp: For testing queue implentation
Customer.hpp: Customer class with some helper functions
Bank.cpp: Bank problem
