BinNode.hpp: Node for binary tree
BinTree.hpp: Abstract Binary tree class
BST.hpp: Binary Search tree which will implement binary tree class
main.cpp: BST implementation tester
input.txt: input file