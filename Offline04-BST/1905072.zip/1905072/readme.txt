BinNode.hpp: Node for binary tree
BinTree.hpp: Abstract Binary tree class
BSTNode.hpp: Node for binary search tree which will implement BinNode
BST.hpp: Binary Search tree which will implement BinTree
main.cpp: BST implementation tester
input.txt: input file