Stack.hpp: Abstract Stack class
AStack.hpp: Array based stack which will implement stack class
Link.hpp: Node for linked stack
LStack.hpp: Link based stack which will implement stack class
main.cpp: For testing stack implentation
Dishwasher.cpp: Dishwasher problem
