BinNode.hpp: Node for binary tree
BinTree.hpp: Binary tree class
BSTNode.hpp: Node for binary search tree which will extend BinNode
BST.hpp: Binary Search tree which will extend BinTree
main.cpp: BST implementation tester
input.txt: input file